rm -rf ./output.txt && python ./process.py >> ./output.txt
